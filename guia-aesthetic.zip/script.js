function responder() {
  const pergunta = document.getElementById("pergunta").value.toLowerCase();
  let resposta = "";

  if (pergunta.includes("preço") || pergunta.includes("custa")) {
    resposta = "O guia custa R$10,00.";
  } else if (pergunta.includes("como funciona")) {
    resposta = "Funciona com estratégias, alimentação, exercícios/alongamentos e rotinas do guia.";
  } else if (pergunta.includes("incluso") || pergunta.includes("vem")) {
    resposta = "Está incluso: guia para aumento natural da altura, conteúdo, shape e emagrecimento.";
  } else if (pergunta.includes("link") || pergunta.includes("acesso")) {
    resposta = "Você pode acessar o guia aqui: https://linktr.ee/guia_aesthetic";
  } else {
    resposta = "Desculpe, não entendi. Tente perguntar sobre o preço, funcionamento, o que está incluso ou pedir o link.";
  }

  document.getElementById("resposta").innerText = resposta;
}